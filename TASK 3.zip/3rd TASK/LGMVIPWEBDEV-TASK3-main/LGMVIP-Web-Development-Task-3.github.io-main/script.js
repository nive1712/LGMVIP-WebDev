const data = [
    {
        name: "NIVEDHA",
        Register_number :"11111",
        Maths:"A+",
        English: "A+",
        JAVA: "A",
        Physics:"O",
        TOTAL: "8.8"
    },  
    {
        name: "SARULATHA",
        Register_number :"22222",
        Maths:"O",
        English: "A",
        JAVA: "A",
        Physics:"A+",
        TOTAL:"8.7"
        
    },
    
    {
        name: "PUGAZH",
        Register_number :"33333",
        Maths:"A",
        English: "A+",
        JAVA: "A",
        Physics:"A",
        TOTAL:"8.6"
        
    }
]

const results = document.getElementById('res')

const smBtn = document.getElementById('smt-btn')
smBtn.addEventListener("click", function() {
    const name = document.getElementById('name-box').value;
    for(let i = 0; i < data.length; i++){
        if(data[i].name.toLowerCase() == name.toLowerCase()){
            console.log(data[i].marks)
            results.innerHTML ="<h3>" + "Maths : " + data[i].Maths +"</h3>" + "<h3>" + " English: " 
            + data[i].English +"</h3>" +"<h3>" + "JAVA: " + data[i].JAVA +"</h3>"+"<h3>" + "Physics: " + data[i].Physics + "</h3>"
            " TOTAL: " +data[i].TOTAL + "</h3>"
            return;
        }
    }
    results.innerHTML = "<h3>" + "Information is unavailable!!!" + "</h3>" 

}) 